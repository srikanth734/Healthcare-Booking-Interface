
import { useParams } from "react-router-dom";
import { useState } from "react";

const BookAppointment = () => {
  const { id } = useParams();
  const [form, setForm] = useState({ name: "", email: "", date: "", time: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: any) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e: any) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) return <div className="p-4 text-center text-green-600">Appointment booked successfully!</div>;

  return (
    <form onSubmit={handleSubmit} className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Book Appointment</h1>
      <input className="w-full mb-2 p-2 border" placeholder="Name" name="name" required onChange={handleChange} />
      <input className="w-full mb-2 p-2 border" placeholder="Email" name="email" type="email" required onChange={handleChange} />
      <input className="w-full mb-2 p-2 border" name="date" type="date" required onChange={handleChange} />
      <input className="w-full mb-2 p-2 border" name="time" type="time" required onChange={handleChange} />
      <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded">Confirm</button>
    </form>
  );
};

export default BookAppointment;
