
import { useDoctors } from "../context/DoctorsContext";
import { Link } from "react-router-dom";

const LandingPage = () => {
  const { doctors } = useDoctors();

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Available Doctors</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {doctors.map((doc: any) => (
          <Link to={`/doctor/${doc.id}`} key={doc.id} className="border p-4 rounded-lg shadow hover:bg-gray-100">
            <img src={doc.image} alt={doc.name} className="w-24 h-24 rounded-full object-cover" />
            <h2 className="text-xl mt-2">{doc.name}</h2>
            <p className="text-sm text-gray-600">{doc.specialization}</p>
            <p className={doc.available ? "text-green-500" : "text-red-500"}>
              {doc.available ? "Available" : "Unavailable"}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default LandingPage;
