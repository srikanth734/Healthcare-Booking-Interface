
import { useParams, Link } from "react-router-dom";
import { useDoctors } from "../context/DoctorsContext";

const DoctorProfile = () => {
  const { id } = useParams();
  const { doctors } = useDoctors();
  const doctor = doctors.find((doc: any) => doc.id === id);

  if (!doctor) return <p>Doctor not found</p>;

  return (
    <div className="p-4 max-w-xl mx-auto">
      <img src={doctor.image} alt={doctor.name} className="w-32 h-32 rounded-full mb-4" />
      <h1 className="text-2xl font-bold">{doctor.name}</h1>
      <p>{doctor.specialization}</p>
      <p className="my-2">{doctor.bio}</p>
      <p className={doctor.available ? "text-green-500" : "text-red-500"}>
        {doctor.available ? "Available" : "Currently Unavailable"}
      </p>
      {doctor.available && (
        <Link to={`/book/${doctor.id}`} className="mt-4 inline-block bg-blue-600 text-white py-2 px-4 rounded">
          Book Appointment
        </Link>
      )}
    </div>
  );
};

export default DoctorProfile;
