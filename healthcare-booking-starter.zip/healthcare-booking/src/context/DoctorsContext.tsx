
import { createContext, useContext, useState, ReactNode } from "react";
import doctorsData from "../data/doctors.json";

const DoctorsContext = createContext<any>(null);

export const DoctorsProvider = ({ children }: { children: ReactNode }) => {
  const [doctors] = useState(doctorsData);
  return (
    <DoctorsContext.Provider value={{ doctors }}>
      {children}
    </DoctorsContext.Provider>
  );
};

export const useDoctors = () => useContext(DoctorsContext);
